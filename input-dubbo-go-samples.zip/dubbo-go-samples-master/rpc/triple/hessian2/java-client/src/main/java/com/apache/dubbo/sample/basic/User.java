package com.apache.dubbo.sample.basic;

import java.io.Serializable;

public class User implements Serializable {
    String name;
    String id;
    int age;
}
