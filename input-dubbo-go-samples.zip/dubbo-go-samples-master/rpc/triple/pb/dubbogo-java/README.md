# dubbogo-java

Most of the procedure are same with [dubbogo-grpc](../dubbogo-grpc), like compiling proto file.

## Getting Started

1. Start the java server:
    - Use goland to start triple/gojava-go-server
    - Execute `sh run.sh` in the java-server folder to start the java server
2. Start the client
    - Use goland to start triple/gojava-go-client
    - Execute `sh run.sh` under the java-client folder to start the java client

