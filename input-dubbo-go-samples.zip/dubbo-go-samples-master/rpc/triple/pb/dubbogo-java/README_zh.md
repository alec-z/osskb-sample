# dubbogo-java

大部分步骤与 [dubbogo-grpc](../dubbogo-grpc) 一样，如编译 proto 文件。

## 开始

1. 启动服务端
    - 使用 goland 启动 triple/gojava-go-server
    - 在 java-server 文件夹下执行 `sh run.sh` 启动 java server
2. 启动客户端
    - 使用 goland 启动 triple/gojava-go-client
    - 在 java-client 文件夹下执行 `sh run.sh` 启动 java client